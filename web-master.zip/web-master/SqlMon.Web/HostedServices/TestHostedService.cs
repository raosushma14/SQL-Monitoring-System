﻿using Microsoft.Extensions.Hosting;
using SqlMon.Data;
using SqlMon.MonitoringService;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SqlMon.Web.HostedServices
{
    public class TestHostedService : BackgroundService
    {
        private IDataService dataService;

        public TestHostedService(IDataService dataService)
        {
            this.dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await ExecuteActionAsync();
                await Task.Delay(5000);
            }

        }

        private async Task ExecuteActionAsync()
        {
            //foreach (var conn in await dataService.FetchDatabaseServersAsync(null))
            //{
            //    IMonitoringService monitoringService = MonitoringServiceFactory.CreateMonitoringService(conn.ConnectionString);
            //    var specs = await monitoringService.GetServerSpecsAsync();
            //}

            //Debug.WriteLine($"Task Execution Completed at {DateTime.Now}");
            Console.WriteLine($"Task Execution Completed at {DateTime.Now}");
        }
    }
}
