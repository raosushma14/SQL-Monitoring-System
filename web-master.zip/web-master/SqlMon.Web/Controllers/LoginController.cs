﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SqlMon.Common.DapperDataModels;
using SqlMon.Data;
using SqlMon.Web.Models;

namespace SqlMon.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IDataService dataService;

        public LoginController(IDataService dataService)
        {
            this.dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
        }

        [HttpPost]
        public async Task<IActionResult> POST([FromBody]LoginRequestModel model) //Perform Login
        {
            var result = await dataService.PerformLoginAsync(model.Email, model.Password);
            if (result.Validation.Successful)
            {
                return Ok(result.User);
            }
            else
            {
                return Unauthorized(result.Validation);
            }
        }
    }
}