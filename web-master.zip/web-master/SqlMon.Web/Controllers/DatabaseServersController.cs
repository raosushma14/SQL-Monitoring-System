﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SqlMon.Data;
using SqlMon.Web.Models;

namespace SqlMon.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DatabaseServersController : ControllerBase
    {
        private IDataService dataService;

        public DatabaseServersController(IDataService dataService)
        {
            this.dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
        }

        [HttpGet("forUserId/{userId}/random")]
        public async Task<IActionResult> GetForUserId_Random([FromRoute]int userId)
        {
            var data = new DatabaseServersResponseModel();
            Random random = new Random();
            var SampleDisplayNames = new[] 
            {
                "EasyTrace Db", "SqlMon Db", "MASIA Db",
                "mStatus Db", "MINT Db", "Hubble Db"
            };
            var SampleUserNames = new[]
            {
                new User
                {
                    Email = "apavate@miraclesoft.com",
                    Firstname = "Akash",
                    Lastname = "Pavate",
                    DisplayName = "Akash Pavate",
                    UserId = 1
                },
                new User
                {
                    Email = "vrajendra@miraclesoft.com",
                    Firstname = "Vikas",
                    Lastname = "Rajendra",
                    DisplayName = "Vikas Rajendra",
                    UserId = 2
                },
                new User
                {
                    Email = "sdesai@miraclesoft.com",
                    Firstname = "Sangeeta",
                    Lastname = "Desai",
                    DisplayName = "Sangeeta Desai",
                    UserId = 3
                },
                new User
                {
                    Email = "sdesai@miraclesoft.com",
                    Firstname = "Sangeeta",
                    Lastname = "Desai",
                    DisplayName = "Sangeeta Desai",
                    UserId = 3
                },
                new User
                {
                    Email = "ssahu2@miraclesoft.com",
                    Firstname = "Sunil",
                    Lastname = "Sahu",
                    DisplayName = "Sunil Sahu",
                    UserId = 4
                }
            };
            data.DatabaseServers = new List<DatabaseServer>();
            for (int i = random.Next(5, 10); i > 0; i--)
            {
                int IOTotal = random.Next(1, 10000);
                data.DatabaseServers.Add(new DatabaseServer
                {
                    DatabaseServerId = i,
                    Deleted = random.Next(0, 2) == 1 ? true : false,
                    Paused = random.Next(0, 2) == 1 ? true : false,
                    DisplayName = SampleDisplayNames[random.Next(0, SampleDisplayNames.Length)],
                    CreatedByUser = SampleUserNames[random.Next(0, SampleUserNames.Length)],
                    Metrics = new DatabaseServerMetrics
                    {
                        BuildNumber = "13.0.5264.1",
                        ServerVersion = "SQL Server 2016 SP1+",
                        ResponseTimeInMilliseconds = random.Next(0, 6),
                        UsersSessionsCount = random.Next(50, 150),
                        SQLCPUUsagePercentage = random.Next(0, 101),
                        SQLMemoryUsagePercentage = random.Next(0, 101),
                        SQLDiskIOTotal = IOTotal,
                        SQLDiskIOValue = random.Next(1, IOTotal)
                    }
                });
            }

            return Ok(data);
        }

        [HttpGet("forUserId/{userId}")]
        public async Task<IActionResult> GetForUserId([FromRoute]int userId)
        {
            try
            {
                var servers = await dataService.FetchDatabaseServersForUserIdAsync(userId);
                if(servers == null || servers.Count() == 0)
                {
                    return NotFound();
                }

                return Ok(servers);
            }
            catch (Exception E)
            {
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}