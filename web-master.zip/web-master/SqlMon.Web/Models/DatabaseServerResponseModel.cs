﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlMon.Web.Models
{
    public class DatabaseServersResponseModel
    {
        public List<DatabaseServer> DatabaseServers { get; set; }
    }
    public class DatabaseServer
    {
        public int DatabaseServerId { get; set; }
        public string DisplayName { get; set; }

        public User CreatedByUser { get; set; }

        public bool Paused { get; set; }
        public bool Deleted { get; set; }

        public DatabaseServerMetrics Metrics { get; set; }
    }

}
