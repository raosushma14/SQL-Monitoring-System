﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlMon.Web.Models
{
    public class DatabaseServerMetrics
    {
        public string ServerVersion { get; set; }
        public string BuildNumber { get; set; }

        public int ResponseTimeInMilliseconds { get; set; }
        public int UsersSessionsCount { get; set; }
        public int SQLCPUUsagePercentage { get; set; }
        public int SQLMemoryUsagePercentage { get; set; }
        public int SQLDiskIOValue { get; set; }
        public int SQLDiskIOTotal { get; set; }
        public double SQLDiskIOPercentage => Math.Round(SQLDiskIOValue / (float)SQLDiskIOTotal * 100, 2);
    }
}
