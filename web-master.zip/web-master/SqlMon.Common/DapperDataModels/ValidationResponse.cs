﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.Common.DapperDataModels
{
    public class ValidationResponse
    {
        public bool Successful { get; set; }
        public string Message { get; set; }
    }
}
