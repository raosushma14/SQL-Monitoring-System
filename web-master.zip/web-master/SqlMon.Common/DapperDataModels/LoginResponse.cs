﻿using SqlMon.Common.DapperDataModels.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.Common.DapperDataModels
{
    public class LoginResponse
    {
        public ValidationResponse Validation { get; set; }
        public User User { get; set; }
    }
}
