﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.Common.DapperDataModels.Entities
{
    public class DatabaseServer
    {
        public int DatabaseServerId { get; set; }
        public string DisplayName { get; set; }
        public string ConnectionString { get; set; }
        public long CreatedByUserId { get; set; }
        public string CreatedByUser_Firstname { get; set; }
        public string CreatedByUser_Lastname { get; set; }
        public string CreatedByUser_Email { get; set; }
        public string CreatedByUser_DisplayName { get; set; }
        public bool Paused { get; set; }
        public bool Deleted { get; set; }
    }
}
