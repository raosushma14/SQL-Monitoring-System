﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.Common.DapperDataModels.Entities
{
    public class User
    {
        public long? UserId { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string DisplayName { get; set; }
        public int? UserRoleId { get; set; }
        public string UserRoleName { get; set; }
        public int? LoginTypeId { get; set; }
        public string LoginTypeName { get; set; }
    }
}
