﻿using System;
using System.Collections.Generic;
using System.Text;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Linq;

namespace SqlMon.MonitoringService.Implementation
{
    internal class MonitoringService : IMonitoringService
    {
        private readonly string ConnectionString;

        public MonitoringService(string connectionString)
        {
            ConnectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        //public async Task<ServerSpecs> GetServerSpecsAsync()
        //{
        //    string query = @"
        //        SELECT  
        //          SERVERPROPERTY('MachineName') AS ComputerName,
        //          SERVERPROPERTY('ServerName') AS InstanceName,  
        //          SERVERPROPERTY('Edition') AS Edition,
        //          SERVERPROPERTY('ProductVersion') AS ProductVersion,  
        //          SERVERPROPERTY('ProductLevel') AS ProductLevel;  
        //    ";

        //    using (var connection = GetConnection())
        //    {
        //        var specs = await connection.QueryAsync<ServerSpecs>(query);
        //        return specs.Single();
        //    }
        //}

        private IDbConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
