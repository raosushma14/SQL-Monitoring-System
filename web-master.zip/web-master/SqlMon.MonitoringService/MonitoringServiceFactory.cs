﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.MonitoringService
{
    public class MonitoringServiceFactory
    {
        public static IMonitoringService CreateMonitoringService(string connectionString)
        {
            return new Implementation.MonitoringService(connectionString);
        }
    }
}
