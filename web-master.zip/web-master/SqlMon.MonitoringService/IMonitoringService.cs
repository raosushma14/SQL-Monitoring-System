﻿using System;
using System.Threading.Tasks;

namespace SqlMon.MonitoringService
{
    public interface IMonitoringService
    {
        
    }
}
