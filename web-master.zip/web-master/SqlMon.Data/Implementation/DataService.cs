﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using SqlMon.Common.DapperDataModels;
using Dapper;
using SqlMon.Common.DapperDataModels.Entities;
using System.Threading.Tasks;
using System.Linq;

namespace SqlMon.Data.Implementation
{
    internal partial class DataService : IDataService
    {
        private readonly string ConnectionString;

        public DataService(string connectionString)
        {
            ConnectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        public async Task<LoginResponse> PerformLoginAsync(string email, string password)
        {
            var sql = "[dbo].[SP_PerformUserLogin]";
            var parameters = new DynamicParameters();
            parameters.Add("@Email", email);
            parameters.Add("@Password", password);
            parameters.Add("@ResponseMessage", dbType: DbType.String, size: 5215585, direction: ParameterDirection.Output);

            try
            {
                using (var connection = GetConnection())
                {
                    var user = (await connection.QueryAsync<User>(sql, parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                    string responseMessage = parameters.Get<string>("@ResponseMessage");
                    bool success = responseMessage == "User login successful" ? true : false;
                    return new LoginResponse
                    {
                        Validation = new ValidationResponse
                        {
                            Successful = responseMessage == "User login successful" ? true : false,
                            Message = responseMessage
                        },
                        User = user
                    };
                }
            }
            catch (Exception E)
            {
                throw E;
            }
        }

        private IDbConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
