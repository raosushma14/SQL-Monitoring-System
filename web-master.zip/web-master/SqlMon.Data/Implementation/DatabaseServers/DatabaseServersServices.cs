﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using SqlMon.Common.DapperDataModels.Entities;

namespace SqlMon.Data.Implementation
{
    partial class DataService
    {
        public async Task<IEnumerable<DatabaseServer>> FetchDatabaseServersAsync()
        {
            var sql = @"
                        SELECT
	                        DatabaseServerId,
	                        DisplayName,
	                        ConnectionString,
	                        CreatedBy,
	                        Paused,
	                        Deleted
                        FROM 
	                        [dbo].[DatabaseServers]                        
                    ";

            using (var connection = GetConnection())
            {
                var servers = await connection.QueryAsync<DatabaseServer>(sql);
                return servers;
            }
        }

        public async Task<IEnumerable<DatabaseServer>> FetchDatabaseServersByIdAsync(int DatabaseServerId)
        {
            var sql = @"
                        SELECT
	                        DatabaseServerId,
	                        DisplayName,
	                        ConnectionString,
	                        CreatedBy,
	                        Paused,
	                        Deleted
                        FROM 
	                        [dbo].[DatabaseServers]
                        WHERE DatabaseServerId = @DatabaseServerId;
                    ";
            var parameters = new
            {
                DatabaseServerId
            };
            using (var connection = GetConnection())
            {
                var servers = await connection.QueryAsync<DatabaseServer>(sql, parameters);
                return servers;
            }
        }

        public async Task<IEnumerable<DatabaseServer>> FetchDatabaseServersForUserIdAsync(int UserId)
        {
            var sql = @"
                    DECLARE @UserRoleId INT;

                    SELECT @UserRoleId = UserRoleId FROM [dbo].[Users] where UserId = @UserId

                    IF( [dbo].[FN_ToUserRoleName](@UserRoleId) = 'SUPER_ADMIN' )
                    BEGIN
		                    SELECT
			                    DS.DatabaseServerId,
			                    DS.DisplayName,
			                    
			                    DS.CreatedBy AS CreatedByUserId,
			                    U.Firstname AS CreatedByUser_Firstname,
			                    U.Lastname AS CreatedByUser_Lastname,
			                    U.Email AS CreatedByUser_Email,
			                    U.Firstname + ' ' + U.Lastname AS CreatedByUser_DisplayName,
			                    DS.Paused,
			                    DS.Deleted
	                    FROM 
			                    [dbo].[DatabaseServers] DS
	                    INNER JOIN [dbo].[Users] U ON DS.CreatedBy = U.UserId
                    END
                    ELSE
                    BEGIN
	                    SELECT
			                    DS.DatabaseServerId,
			                    DS.DisplayName,
			                    
			                    DS.CreatedBy AS CreatedByUserId,
			                    U.Firstname AS CreatedByUser_Firstname,
			                    U.Lastname AS CreatedByUser_Lastname,
			                    U.Email AS CreatedByUser_Email,
			                    U.Firstname + ' ' + U.Lastname AS CreatedByUser_DisplayName,
			                    DS.Paused,
			                    DS.Deleted
	                    FROM 
			                    [dbo].[DatabaseServers] DS
	                    INNER JOIN [dbo].[Users] U ON DS.CreatedBy = U.UserId
	                    WHERE	CreatedBy = @UserId
			                    OR DS.DatabaseServerId IN (SELECT DatabaseServerId FROM [dbo].[DatabaseServerUserAccess] WHERE UserId = @UserId)
                    END
                    ";
            var parameters = new
            {
                UserId
            };
            try
            {
                using (var connection = GetConnection())
                {
                    var servers = await connection.QueryAsync<DatabaseServer>(sql, parameters);
                    return servers;
                }
            }
            catch (Exception E)
            {
                if(E.Message.Contains("No record found"))
                {
                    return null;
                }

                throw E;
            }
        }
    }
}
