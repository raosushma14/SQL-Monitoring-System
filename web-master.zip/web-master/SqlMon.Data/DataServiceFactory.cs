﻿using SqlMon.Data.Implementation;
using System;
using System.Collections.Generic;
using System.Text;

namespace SqlMon.Data
{
    public class DataServiceFactory
    {
        public static IDataService CreateDataService(string connectionString)
        {
            return new Implementation.DataService(connectionString);
        }
    }
}
