﻿using SqlMon.Common.DapperDataModels;
using SqlMon.Common.DapperDataModels.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SqlMon.Data
{
    public interface IDataService
    {
        Task<LoginResponse> PerformLoginAsync(string email, string password);

        Task<IEnumerable<DatabaseServer>> FetchDatabaseServersAsync();
        Task<IEnumerable<DatabaseServer>> FetchDatabaseServersByIdAsync(int Id);
        Task<IEnumerable<DatabaseServer>> FetchDatabaseServersForUserIdAsync(int UserId);
        
    }
}
